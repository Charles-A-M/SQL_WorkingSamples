## SQL Server Markov Name Generator

Built against SQL Server 2016, using the dataset at ftp://ftp.heise.de/pub/ct/listings/0717-182.zip

For a little background on this project, see the following Stack Exchange post: https://worldbuilding.stackexchange.com/questions/91026/database-of-real-historical-names

## Build

Clone the repo, and execute the .sql files in the specified order

## Use

Use instructions forthcoming