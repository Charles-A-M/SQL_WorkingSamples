using System;
using System.Collections;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Text;
using System.Web;
using System.Web.SessionState;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.HtmlControls;

namespace Excuses
{
	/// <summary>
	/// Summary description for Excuses.
	/// </summary>
	public class Excuses : System.Web.UI.Page
	{
		protected System.Web.UI.WebControls.TextBox Firm;
		protected System.Web.UI.WebControls.TextBox Project;
		protected System.Web.UI.WebControls.TextBox Department;
		protected System.Web.UI.WebControls.TextBox Name;
		protected System.Web.UI.WebControls.Button Generate;
		protected System.Web.UI.WebControls.Label ExcuseText;
		protected System.Web.UI.WebControls.Label ProjectLabel;
		protected System.Web.UI.WebControls.PlaceHolder ExcusePlaceHolder;
		protected System.Web.UI.HtmlControls.HtmlForm Form1;
		protected System.Web.UI.WebControls.RequiredFieldValidator FirmRequiredfieldvalidator;
		protected System.Web.UI.WebControls.RequiredFieldValidator ProjectRequiredfieldvalidator;
		protected System.Web.UI.WebControls.RequiredFieldValidator DepartmentRequiredfieldvalidator;
		protected System.Web.UI.WebControls.RequiredFieldValidator NameRequiredfieldvalidator;
		protected System.Web.UI.WebControls.Label FirmLabel;
	
		private void Page_Load(object sender, System.EventArgs e)
		{
			// Put user code to initialize the page here
		}

		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Generate.Click += new System.EventHandler(this.Generate_Click);
			this.Load += new System.EventHandler(this.Page_Load);

		}
		#endregion

		private void Generate_Click(object sender, System.EventArgs e)
		{
			if(Page.IsValid)
			{
				StringBuilder essay = new StringBuilder();

				using(SqlConnection connection = new SqlConnection(ConfigurationSettings.AppSettings["dsn"]))
				{
					connection.Open();

					SqlCommand spCreateEssay = new SqlCommand("spCreateEssay", connection);
					spCreateEssay.CommandType = CommandType.StoredProcedure;

					spCreateEssay.Parameters.Add("@Organisation", SqlDbType.VarChar, 50);
					spCreateEssay.Parameters.Add("@ProjectName", SqlDbType.VarChar, 50);
					spCreateEssay.Parameters.Add("@MyTeam", SqlDbType.VarChar, 50);
					spCreateEssay.Parameters.Add("@MyName", SqlDbType.VarChar, 50);

					spCreateEssay.Parameters["@Organisation"].Value = Firm.Text;
					spCreateEssay.Parameters["@ProjectName"].Value = Project.Text;
					spCreateEssay.Parameters["@MyTeam"].Value = Department.Text;
					spCreateEssay.Parameters["@MyName"].Value = Name.Text;

					using(SqlDataReader sdr = spCreateEssay.ExecuteReader())
					{
						while(sdr.Read())
						{
							essay.Append(sdr.GetString(0));
						}
					}
				}

				ExcusePlaceHolder.Visible = true;
				ExcuseText.Text = essay.ToString();
				ProjectLabel.Text = Project.Text;
				FirmLabel.Text = Firm.Text;
			}
			else
			{
				ExcusePlaceHolder.Visible = false;
			}
		}
	}
}
