/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

-- settings

-- DATEFIRST

SELECT @@DATEFIRST DF, DATEPART(dw, GETDATE()) day;

SET DATEFIRST 1;
SELECT @@DATEFIRST DF, DATEPART(dw, GETDATE()) day;

SET DATEFIRST 2;
SELECT @@DATEFIRST DF, DATEPART(dw, GETDATE()) day;

SET DATEFIRST 3;
SELECT @@DATEFIRST DF, DATEPART(dw, GETDATE()) day;

SET DATEFIRST 7;
SELECT @@DATEFIRST DF, DATEPART(dw, GETDATE()) day;

-- DATEFORMAT

SET DATEFORMAT MDY;
SELECT CONVERT(datetime, '12/11/10');
SET DATEFORMAT DMY;
SELECT CONVERT(datetime, '12/11/10');
SET DATEFORMAT YMD;
SELECT CONVERT(datetime, '12/11/10');
SET DATEFORMAT MYD;
SELECT CONVERT(datetime, '12/11/10');
SET DATEFORMAT DYM;
SELECT CONVERT(datetime, '12/11/10');

-- LANGUAGE

SET LANGUAGE English;
SELECT 11, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '11/13/10');
SELECT 12, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '12/11/10');
SELECT 13, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '13/11/10');

SET LANGUAGE British;
SELECT 11, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '11/13/10');
SELECT 12, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '12/11/10');
SELECT 13, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '13/11/10');

SET LANGUAGE slovenski;
SELECT 11, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '11/13/10');
SELECT 12, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '12/11/10');
SELECT 13, @@LANGUAGE lang, DATENAME(month,GETDATE()) month, CONVERT(datetime, '13/11/10');

-- take your pick!
select * from sys.syslanguages;

-- OTHER SETTINGS

-- set forceplan
-- set noexec
-- set parseonly
-- set query_governor_cost_limit 1;
-- set lock_timeout 1; -- milliseconds!