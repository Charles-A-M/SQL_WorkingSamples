/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

-- generate 0-255
DECLARE @i TABLE(i TINYINT NOT NULL UNIQUE)
;WITH n(n) AS (SELECT 0 UNION ALL SELECT n+1 FROM n WHERE n<255)
INSERT @i SELECT * FROM n OPTION(MAXRECURSION 256)

-- generate all Unicode from 0x0 to 0xFFFF (note: not all are valid)
;WITH n(n) AS (SELECT a.i*256+b.i FROM @i a CROSS JOIN @i b),
	a(n,lo,hi,uni) AS 
	(SELECT n, SUBSTRING('0123456789ABCDEF',n%16+1,1) lo,
	CONVERT(CHAR(6),CAST(n/16*16 AS BINARY(2)),1) hi, NCHAR(n) uni
	FROM n)
SELECT hi hi_byte,[0],[1],[2],[3],[4],[5],[6],[7],[8],[9],[A],[B],[C],[D],[E],[F]
FROM (SELECT hi,lo,uni FROM a) y
PIVOT (MAX(uni) 
FOR lo IN ([0],[1],[2],[3],[4],[5],[6],[7],[8],[9],[A],[B],[C],[D],[E],[F])) z
