﻿/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

-- must run in SQLCMD mode!

:setvar db "AW1"	-- chage to AW1, AW2, etc. through AW7

-- AdventureWorks variations
USE [master]
GO
CREATE DATABASE [$(db)] CONTAINMENT = NONE ON PRIMARY 
(NAME=N'Data',FILENAME=N'C:\SQLData\$(db).mdf',SIZE=3MB,MAXSIZE=8MB,FILEGROWTH=1MB)
LOG ON 
(NAME=N'Log',FILENAME=N'C:\SQLLogs\$(db).ldf',SIZE=2MB,MAXSIZE=8MB,FILEGROWTH=1MB)
GO

RETURN;

-- modify DB names
ALTER DATABASE AW1 MODIFY NAME = [АdventureWorks];
ALTER DATABASE AW2 MODIFY NAME = [Adventure‮skroW];
ALTER DATABASE AW3 MODIFY NAME = [‮skroWerutnevdA];
ALTER DATABASE AW4 MODIFY NAME = [‮skroWerutnevdА];
ALTER DATABASE AW5 MODIFY NAME = [Αdventure‮skroW];
ALTER DATABASE AW6 MODIFY NAME = [A	d	v	e	n	t	u	r	e	W	o	r	k	s];
ALTER DATABASE AW7 MODIFY NAME = [A
d
v
e
n
t
u
r
e
W
o
r
k
s];

select db_name(database_id), name, physical_name 
from sys.master_files;

RETURN;

-- Other databases

USE [master]
GO

CREATE DATABASE [ ]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'', FILENAME = N'c:\sqldata\ .mdf' , SIZE = 3MB , MAXSIZE = 3MB, FILEGROWTH = 0KB )
 LOG ON 
( NAME = N' _log', FILENAME = N'c:\sqllogs\ _log.ldf' , SIZE = 2MB , MAXSIZE = 2MB , FILEGROWTH = 0KB)
GO

CREATE DATABASE [ ]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N' ', FILENAME = N'c:\sqldata\ .mdf' , SIZE = 3264KB , MAXSIZE = 4MB, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N' _log', FILENAME = N'c:\sqllogs\ _log.ldf' , SIZE = 832KB , MAXSIZE = 4MB, FILEGROWTH = 0)
GO

CREATE DATABASE [	]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'data', FILENAME = N'c:\sqldata\tab.mdf' , SIZE = 3072KB , MAXSIZE = 4MB, FILEGROWTH = 0)
 LOG ON 
( NAME = N'log', FILENAME = N'c:\sqllogs\tab.ldf' , SIZE = 1024KB , MAXSIZE = 4MB , FILEGROWTH = 0)
GO

CREATE DATABASE [?]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'Data', FILENAME = N'C:\SQLData\question' , SIZE = 4096KB , MAXSIZE = 4MB, FILEGROWTH = 0)
 LOG ON 
( NAME = N'Log', FILENAME = N'C:\SQLLogs\question' , SIZE = 2048KB , MAXSIZE = 4MB , FILEGROWTH = 0)
GO

CREATE DATABASE [CREATE DATABASE]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'CREATE DATABASE', FILENAME = N'C:\SQLData\CREATE DATABASE.mdf' , SIZE = 3264KB , MAXSIZE = 4MB, FILEGROWTH = 0 )
 LOG ON 
( NAME = N'CREATE DATABASE_log', FILENAME = N'C:\SQLLogs\CREATE DATABASE_log.ldf' , SIZE = 816KB , MAXSIZE = 4MB , FILEGROWTH = 0)
GO

CREATE DATABASE [DupeObjs]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'DupeObjs', FILENAME = N'C:\SQLData\DupeObjs.mdf' , SIZE = 16MB , MAXSIZE = 4MB, FILEGROWTH = 1024KB )
 LOG ON 
( NAME = N'DupeObjs_log', FILENAME = N'C:\SQLLogs\DupeObjs_log.ldf' , SIZE = 3072KB , MAXSIZE = 4MB, FILEGROWTH = 1024KB )
GO

