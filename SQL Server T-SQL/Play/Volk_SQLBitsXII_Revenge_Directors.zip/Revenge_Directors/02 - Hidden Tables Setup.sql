/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

use [ ];

-- generate CREATE SCHEMA for schema that don't currently exist
SELECT 'CREATE SCHEMA ' + QUOTENAME(name) FROM Adventureworks.sys.schemas
except
SELECT 'CREATE SCHEMA ' + QUOTENAME(name) FROM sys.schemas;

WITH CTE (sch,obj) AS (
select OBJECT_SCHEMA_NAME(object_id,db_id('AdventureWorks')), name 
from AdventureWorks.sys.tables where object_id>100
union
select OBJECT_SCHEMA_NAME(object_id,db_id('AdventureWorks')), name 
from AdventureWorks.sys.views where object_id>100
union
select OBJECT_SCHEMA_NAME(object_id,db_id('AdventureWorks')), name 
from AdventureWorks.sys.procedures where object_id>100
union
select OBJECT_SCHEMA_NAME(object_id,db_id('AdventureWorks')), name
from AdventureWorks.sys.objects where type_desc like '%function%')
select 'CREATE SYNONYM ' + QUOTENAME(sch) + '.' + QUOTENAME(obj) + 
' FOR [AdventureWorks].' + QUOTENAME(sch) + '.' + QUOTENAME(obj)
from CTE;


return
-- clean up
declare @sql varchar(max)='';
SELECT @sql=N'DROP SYNONYM ' + STUFF((SELECT N',' + QUOTENAME(OBJECT_SCHEMA_NAME(object_id)) + '.' + QUOTENAME(name) FROM sys.synonyms FOR XML PATH('')),1,1,N'')
EXEC(@sql)
GO
