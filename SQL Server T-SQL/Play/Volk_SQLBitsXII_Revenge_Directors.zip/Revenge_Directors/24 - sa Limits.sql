/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

-- sa limits

USE tempdb;

CREATE TABLE NoSA (NoSA int
	CHECK (SUSER_SNAME()<>'sa'),
	name sysname DEFAULT(suser_sname()));

CREATE TABLE NoSysAdmin (NoSysAdmin int
	CHECK (IS_SRVROLEMEMBER('sysadmin')=0),
	name sysname DEFAULT(suser_sname()));

-- try as sysadmin
INSERT NoSA(NoSA) VALUES(1);	--succeeds
INSERT NoSysAdmin(NoSysAdmin) VALUES(1);	--fails

-- change connection to sa
INSERT NoSA(NoSA) VALUES(2);			--fails
INSERT NoSysAdmin(NoSysAdmin) VALUES(2);	--fails

-- change to lame and try again
INSERT NoSA(NoSA) VALUES(3);			--succeeds
INSERT NoSysAdmin(NoSysAdmin) VALUES(3);	--succeeds

SELECT * FROM NoSA;
SELECT * FROM NoSysAdmin;

RETURN;

-- clean up
DROP TABLE NoSA,NoSysAdmin;



-- control SELECT through views

USE AdventureWorks;
GO
CREATE VIEW Sales.vSalesOrderDetail WITH SCHEMABINDING AS
SELECT SalesOrderID, SalesOrderDetailID, CarrierTrackingNumber, OrderQty, ProductID, SpecialOfferID, UnitPrice, UnitPriceDiscount, LineTotal, rowguid, ModifiedDate
FROM Sales.SalesOrderDetail
WHERE ORIGINAL_LOGIN()<>'sa';
GO

:connect .\CALVIN
SELECT ORIGINAL_LOGIN() usr, COUNT(*) FROM AdventureWorks.Sales.vSalesOrderDetail;
GO

:connect .\CALVIN -U sa -P sa
SELECT ORIGINAL_LOGIN() usr, COUNT(*) FROM AdventureWorks.Sales.vSalesOrderDetail;
GO

-- control INSERT/UPDATE/DELETE with triggers

USE AdventureWorks;
GO

-- reciprocation:

CREATE TRIGGER trg_No_SA_SalesOrderDetail ON Sales.SalesOrderDetail AFTER INSERT,UPDATE,DELETE AS
SET NOCOUNT ON;
IF ORIGINAL_LOGIN()='sa' ROLLBACK TRANSACTION;
GO

-- reprisal:

ALTER TRIGGER trg_No_SA_SalesOrderDetail ON Sales.SalesOrderDetail AFTER INSERT,UPDATE,DELETE AS
SET NOCOUNT ON;
IF ORIGINAL_LOGIN()='sa' BEGIN 
	ROLLBACK TRANSACTION;
	RAISERROR('NO. SA. LOGINS!!!',25,1);
END
GO

-- retribution:

ALTER TRIGGER trg_No_SA_SalesOrderDetail ON Sales.SalesOrderDetail AFTER INSERT,UPDATE,DELETE AS
SET NOCOUNT ON;
IF ORIGINAL_LOGIN()='sa' BEGIN 
	ROLLBACK TRANSACTION;
	DECLARE @body nvarchar=N'HEY! ' + HOST_NAME() + N' just tried to use sa!';
	EXEC msdb.dbo.sp_send_dbmail @recipients=N'CEO@yourcompany.com', @subject=N'sa abuse!', @body=@body
	RAISERROR('NO. SA. LOGINS!!!',25,1);
-- too bad the following doesn't work:
-- SHUTDOWN WITH NOWAIT;
-- OR DOES IT??? ;)
-- (hint: check my blog)
END
GO