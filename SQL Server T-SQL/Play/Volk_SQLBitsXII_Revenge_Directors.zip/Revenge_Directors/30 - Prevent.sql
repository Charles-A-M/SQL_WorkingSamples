/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

-- Prevention is worth a metric ton of fun!

-- Prevent ad-hoc INSERT & UPDATE

USE tempdb;

create table NoAdHoc(a int not null, 
	constraint CHKNoAdHoc check(object_name(@@PROCID) is not null))
go

create procedure ins_NoAdHoc @a int as
set nocount on
insert NoAdHoc(a) values(@a)
go

exec ins_NoAdHoc 1;

select * from NoAdHoc

insert NoAdHoc(a) values(2) --fails
select * from NoAdHoc

exec ins_NoAdHoc 3;  --succeeds
update NoAdHoc set a=-a  --fails
select * from NoAdHoc

-- trigger to rollback ad-hoc SQL INSERT/UPDATE
CREATE TABLE c_trig(a INT NOT NULL);
GO
CREATE TRIGGER c_trig_trg ON c_trig FOR INSERT,UPDATE AS
SET NOCOUNT ON;
IF @@NESTLEVEL=TRIGGER_NESTLEVEL() BEGIN
	DECLARE @doofus sysname=ORIGINAL_LOGIN();
	ROLLBACK TRANSACTION;
	RAISERROR(N'%s is a doofus for trying to run ad-hoc SQL.',25,1,@doofus) WITH LOG;
	RETURN;
END
GO

-- to prevent ad-hoc DELETE, use DML trigger
CREATE TRIGGER trg_NoAdHocDelete_NoAdHoc ON NoAdHoc INSTEAD OF DELETE AS
SET NOCOUNT ON;
IF @@NESTLEVEL=TRIGGER_NESTLEVEL() BEGIN 
	ROLLBACK TRANSACTION;
	RAISERROR('No Ad-hoc Deletes!',25,1) WITH LOG;
	RETURN;
END
DELETE a
FROM NoAdHoc A
INNER JOIN deleted D ON A.a=D.a;
GO

create procedure del_NoAdHoc @a int as
set nocount on
delete NoAdHoc where a=@a;
go

select * from NoAdHoc;

delete NoAdHoc;

exec del_NoAdHoc 1;

select * from NoAdHoc;



-- Prevent too many rows from being updated/inserted/deleted
-- WARNING! Practical application!  Sorry...
USE tempdb;

CREATE TABLE a(a int);
GO

CREATE TRIGGER a_TooManyRows ON a FOR INSERT,DELETE,UPDATE AS
IF @@ROWCOUNT>10 BEGIN
	RAISERROR('Too many rows affected, check your WHERE clause, moron.',16,1)
	ROLLBACK TRANSACTION;
END
GO

INSERT a(a) SELECT ROW_NUMBER() OVER (ORDER BY (SELECT NULL))
FROM master..spt_values;

DROP TRIGGER a_TooManyRows;
GO



-- Prevent SELECT * (Courtesy @SQLChicken - Jorge Segarra)

use tempdb;

CREATE TABLE [NoSelect*] (a int not null, [*] AS 1/0);

INSERT [NoSelect*](a) VALUES(1),(2),(3);

SELECT a FROM [NoSelect*];
SELECT * FROM [NoSelect*];

-- clean up
DROP TABLE [NoSelect*];


-- Prevent TRUNCATE

-- Suggested by Derek Colley via twitter
-- create empty table and declare foreign keys to it
-- you can create multiple FKs to same table, and any FK to any other table
-- might be good idea to have a column of every possible data type
-- don't forget FK columns have to be unique in referenced table.

use tempdb;

create table pk(a int check(1=0));
create table fk1(a int not null primary key);
create table fk2(a int not null primary key);

alter table pk add constraint FK_fk1 foreign key(a) references fk1(a);
alter table pk add constraint FK_fk2 foreign key(a) references fk2(a);

alter table pk add constraint FK_fk1a foreign key(a) references fk1(a);
alter table pk add constraint FK_fk2a foreign key(a) references fk2(a);

insert fk1 values(1),(2),(3),(4);
insert fk2 values(1),(2),(3),(4);

deny delete on fk1 to public;
deny delete on fk2 to public;

truncate table fk1;
go
truncate table fk2;
go
delete fk1;

drop table fk1,fk2; -- error
drop table pk;		-- drop first
drop table fk1,fk2;	-- now this works

-- Prevent DROP of tables, without DDL triggers
Use AdventureWorks;
-- create a view that returns no data, just prevents dropping
GO
CREATE VIEW dbo.NoDrop WITH SCHEMABINDING AS
SELECT TOP 0 1 A FROM Sales.SalesOrderDetail WHERE 1=0;
GO

-- run with show exec plan to see nothing happens
SELECT * FROM dbo.NoDrop;

-- now try to drop the table
DROP TABLE Sales.SalesOrderDetail;		-- fails
GO

DROP VIEW dbo.NoDrop;

BEGIN TRAN
	DROP TABLE Sales.SalesOrderDetail;	-- succeeds but gets rolled back
ROLLBACK TRAN


use master;

-- Prevent DROP DATABASE

-- prevent databases from being dropped?  Really????
-- nah, not really, but....
-- command line mayhem ensues
-- mklink to other file

:connect .\HOBBES
use master;
select DB_NAME(database_id) db, physical_name from sys.master_files where DB_NAME(database_id)='AdventureWorks';

-- run linkdb batch file
:connect .\HOBBES
drop database AdventureWorks;
select DB_NAME(database_id) db, physical_name from sys.master_files where DB_NAME(database_id)='AdventureWorks';

:connect .\HOBBES
exec sp_attach_db 'AdventureWorks', 'c:\sqldata\AdventureWorks_hobbes.mdf', 'c:\sqllogs\AdventureWorks_hobbes.ldf';	 -- error

:connect .\HOBBES
-- run relink batch file
-- UAC/admin rights causing problems, show files
exec sp_attach_db 'AdventureWorks', 'c:\sqldata\AdventureWorks_hobbes.mdf', 'c:\sqllogs\AdventureWorks_hobbes.ldf';

