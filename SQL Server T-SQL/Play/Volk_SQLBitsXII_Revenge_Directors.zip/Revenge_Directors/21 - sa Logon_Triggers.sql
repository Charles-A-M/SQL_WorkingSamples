/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

-- Logon Triggers

:connect .\HOBBES
GO
use master;
GO

-- check for logon trigger and drop it

IF EXISTS(SELECT * FROM sys.server_triggers
	WHERE name='SA_LOGIN_PRIORITY')
DROP TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER;
GO

CREATE TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER 
WITH ENCRYPTION, EXECUTE AS N'sa'
AFTER LOGON AS
IF ORIGINAL_LOGIN()<>N'sa' OR APP_NAME() LIKE N'SQL Agent%' RETURN;

-- interesting stuff goes here

GO

-- now for fun stuff:

ALTER TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER 
WITH ENCRYPTION, EXECUTE AS N'sa'
AFTER LOGON AS
IF ORIGINAL_LOGIN()<>N'sa' OR APP_NAME() LIKE N'SQL Agent%' RETURN;

-- reciprocation
WAITFOR DELAY '00:00:10';

-- reprisal
IF EXISTS(SELECT * FROM sys.dm_exec_sessions 
	WHERE session_id=@@SPID AND program_name LIKE '%Access%')
WAITFOR DELAY '00:00:45';

-- retribution
IF EXISTS(SELECT * FROM sys.dm_exec_sessions 
	WHERE session_id=@@SPID AND host_name='I_Hate_This_Person')
WAITFOR DELAY '23:59:59';

GO


-- of course there may be exceptions:

ALTER TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER 
WITH ENCRYPTION, EXECUTE AS N'sa'
AFTER LOGON AS
IF ORIGINAL_LOGIN()<>N'sa' OR APP_NAME() LIKE N'SQL Agent%' RETURN;

-- Well, they really shouldn't, but I'll let it slide:
IF EXISTS(SELECT * FROM sys.dm_exec_sessions 
	WHERE session_id=@@SPID AND host_name='HotGirlInFinance')  -- Workstation ID=
BEGIN
	RAISERROR('You are the most exquisite creature. I am at your service.',10,1) WITH LOG;
	RETURN;
END

-- and now back to the vengeance!
WAITFOR DELAY '00:00:10';

-- reprisal
IF EXISTS(SELECT * FROM sys.dm_exec_sessions 
	WHERE session_id=@@SPID AND program_name LIKE '%Access%')
WAITFOR DELAY '00:00:45';

-- retribution
IF EXISTS(SELECT * FROM sys.dm_exec_sessions 
	WHERE session_id=@@SPID AND host_name='I_Hate_This_Person')
WAITFOR DELAY '23:59:59';

GO

-- clean up because mayhem ensues if you don't
:connect .\HOBBES
IF EXISTS(SELECT * FROM sys.server_triggers
	WHERE name='SA_LOGIN_PRIORITY')
DROP TRIGGER SA_LOGIN_PRIORITY ON ALL SERVER;
GO

