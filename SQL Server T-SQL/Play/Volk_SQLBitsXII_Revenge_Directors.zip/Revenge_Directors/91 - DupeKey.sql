/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

USE DupeObjs;

-- check for primary key constraint
select TABLE_NAME, CONSTRAINT_NAME, CONSTRAINT_TYPE from INFORMATION_SCHEMA.TABLE_CONSTRAINTS
select TABLE_NAME,COLUMN_NAME,CONSTRAINT_NAME from INFORMATION_SCHEMA.KEY_COLUMN_USAGE

-- show data
select * from DupePK;
select * from DupePK2;

--WTF? Dupes in a primary key column???













--... scroll down












-- show the truth
select * from DupePK_Magic;
select * from DupePK2_Magic;
-- scroll further








-- show the REAL truth
select * from DupePK2_Full;
