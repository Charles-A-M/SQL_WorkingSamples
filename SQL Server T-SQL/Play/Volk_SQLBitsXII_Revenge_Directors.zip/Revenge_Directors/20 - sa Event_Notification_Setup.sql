/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

:connect .\CALVIN
USE msdb;
GO

CREATE PROCEDURE dbo.SA_LOGIN_PRIORITY_act
WITH ENCRYPTION AS
DECLARE @x XML, @message nvarchar(max);
RECEIVE @x=CAST(message_body AS XML) FROM SA_LOGIN_PRIORITY_q;
IF @x.value('(//LoginName)[1]','sysname')=N'sa' AND @x.value('(//ApplicationName)[1]','sysname') NOT LIKE N'SQL Agent%'
BEGIN
    -- interesting activation procedure stuff goes here
    DBCC FREEPROCCACHE WITH NO_INFOMSGS;
	DBCC DROPCLEANBUFFERS WITH NO_INFOMSGS;
END
GO

CREATE QUEUE SA_LOGIN_PRIORITY_q 
    WITH STATUS=ON, RETENTION=OFF,
    ACTIVATION (PROCEDURE_NAME=dbo.SA_LOGIN_PRIORITY_act, MAX_QUEUE_READERS=1, EXECUTE AS OWNER);

CREATE SERVICE SA_LOGIN_PRIORITY_s ON QUEUE SA_LOGIN_PRIORITY_q([http://schemas.microsoft.com/SQL/Notifications/PostEventNotification]);

CREATE EVENT NOTIFICATION SA_LOGIN_PRIORITY_en ON SERVER WITH FAN_IN
FOR AUDIT_LOGIN
TO SERVICE N'SA_LOGIN_PRIORITY_s', N'current database';
GO

-- prime cache
:connect .\CALVIN
SELECT TOP 10 * FROM AdventureWorks.Sales.SalesOrderDetail;

-- query cached plans
:connect .\CALVIN
SELECT count(*) FROM sys.dm_exec_cached_plans;

:connect .\CALVIN -U sa -P sa
SELECT count(*) FROM sys.dm_exec_cached_plans;

:connect .\CALVIN
use msdb;

ALTER PROCEDURE dbo.SA_LOGIN_PRIORITY_act
WITH ENCRYPTION AS
DECLARE @x XML, @message nvarchar(max);
RECEIVE @x=CAST(message_body AS XML) FROM SA_LOGIN_PRIORITY_q;
IF @x.value('(//LoginName)[1]','sysname')=N'sa' AND @x.value('(//ApplicationName)[1]','sysname') NOT LIKE N'SQL Agent%'
BEGIN
    IF DB_ID('AdventureWorks') IS NOT NULL
	ALTER DATABASE [AdventureWorks] MODIFY NAME=[AdventureWorks (Suspect)];
END
GO

-- clean up
/*
DROP EVENT NOTIFICATION SA_LOGIN_PRIORITY_en ON SERVER;
DROP SERVICE SA_LOGIN_PRIORITY_s;
DROP QUEUE SA_LOGIN_PRIORITY_q;
DROP PROCEDURE dbo.SA_LOGIN_PRIORITY_act
*/