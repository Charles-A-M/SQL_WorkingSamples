/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/

-- sa abuse leads to MORE sa abuse!

-- logon trigger
:connect .\HOBBES				-- normal
select SERVERPROPERTY('InstanceName') srv, system_user usr;
go

:connect .\HOBBES -U sa -P sa	-- sa
select SERVERPROPERTY('InstanceName') srv, system_user usr;
go

-- Resource Governor
:connect .						-- normal
select SERVERPROPERTY('InstanceName') srv, system_user usr, group_id
from sys.dm_exec_requests where session_id=@@SPID;
go

:connect . -U sa -P sa			-- sa
select SERVERPROPERTY('InstanceName') srv, system_user usr, group_id
from sys.dm_exec_requests where session_id=@@SPID;
GO

-- event notifications
:connect .\CALVIN				-- normal
select SERVERPROPERTY('InstanceName') srv, system_user usr;
go

:connect .\CALVIN -U sa -P sa	-- sa
select SERVERPROPERTY('InstanceName') srv, system_user usr;
go

-- prime cache
:connect .\CALVIN
SELECT TOP 10 * FROM AdventureWorks.Sales.SalesOrderDetail;

-- query cached plans
:connect .\CALVIN
SELECT count(*) FROM sys.dm_exec_cached_plans;

:connect .\CALVIN -U sa -P sa
SELECT count(*) FROM sys.dm_exec_cached_plans;
