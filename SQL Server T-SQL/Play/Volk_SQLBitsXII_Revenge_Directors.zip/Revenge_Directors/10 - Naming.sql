﻿/*
Revenge: The SQL! - Director's Cut
Rob Volk
SQLBits XII - Telford, UK 2014-07-19
*/
 
 -- Naming Conventions

 -- Reserved Words

:connect .	-- change connection
use [ ];
go

-- Make up some reserved name tables and columns
create table [from]([select] varchar(20), [*] varchar(20), [from] varchar(20), [where] varchar(20), [=] varchar(20))
insert [from] values('selectA','*A','from','where','=')
insert [from] values('selectB','*B','from','=','where')
insert [from] values('selectC','*C','from','where','where')

create table [where]([select] varchar(20), [*] varchar(20), [from] varchar(20), [where] varchar(20), [=] varchar(20))
insert [where] values('A','*','from','where','=')
insert [where] values('B','*','from','=','where')
insert [where] values('C','*','from','where','where')

-- Write some SQL that looks pretty weird
select * from [from]
select [select] from [from] where [where] = "="
select * from [from]

-- Then even weirder...watch the quoted identifier settings
select [*] from [from]
select "*" from [from] 
set quoted_identifier off
select "*" from [from] 
set quoted_identifier on

-- the above can be used to misdirect data from one column to another
select * from [where] where [where] = '=';
select * from [where] where [where] = [=];
select * from [where] where [where] = "=";
set quoted_identifier off;
select * from [where] where [where] = "=";
set quoted_identifier on;

-- Clean up
drop table [from], [where];


-- *******************


-- Blank  -- change connection
:connect .
use [ ];
go

-- Create object with single space
create schema [ ] authorization dbo;
go


-- Clean up
exec sp_MSforeachtable 'drop table ?';

-- Watch for trailing spaces!
:connect .
use [ ];
go

-- Create single space table
create table [ ].[ ](a int not null default(1));
go

-- Create hard space table
create table [ ].[ ](a int not null default(2));
go

-- Select tables and ASCII codes
select ascii(name) ASCII_Code, name from sys.tables where object_id>100 order by 1;

-- Create double space table
create table [ ].[  ](a int not null default(3));  -- fails
go

-- Create space-hard space table
create table [ ].[  ](a int not null default(4));
go

-- Create space-hard space-space table
create table [ ].[   ](a int not null default(5));  -- fails
go

-- Select tables and ASCII codes
select ascii(name) ASCII_Code, name from sys.tables where object_id>100 order by 1;


-- table names are RTRIM'd, but not LTRIM'd

-- Create multi-hard space tables
create table [ ].[   ](a int not null default(6));
create table [ ].[   ](a int not null default(7));
create table [ ].[    ](a int not null default(8));
create table [ ].[    ](a int not null default(9));
create table [ ].[
](a int not null default(10));
create table [ ].[

](a int not null default(11));
go

-- Select tables and ASCII codes
select ascii(name) ASCII_Code, name from sys.tables where object_id>100 order by 1;


-- Generate data
exec sp_MSforeachtable 'insert ? default values';	-- different defaults
exec sp_MSforeachtable 'select * from ?';			-- show differences

-- Clean up
exec sp_MSforeachtable 'drop table ?';

drop schema [ ];


-- *******************


-- Hidden

:connect .
use [ ];

select * from sys.tables where object_id>100;

select * from sys.views where object_id>100;

select top 10 * from Sales.SalesOrderDetail;


-- *******************


-- Duplicate

:connect .\CALVIN	-- change connection
SELECT name, UNICODE(name) codepoint FROM sys.databases WHERE database_id>4 ORDER BY name;
GO

-- drag DB names over






-- *******************


-- Unicode

-- generate 0-255
DECLARE @i TABLE(i TINYINT NOT NULL UNIQUE)
;WITH n(n) AS (SELECT 0 UNION ALL SELECT n+1 FROM n WHERE n<255)
INSERT @i SELECT * FROM n OPTION(MAXRECURSION 256)

-- generate all Unicode from 0x0 to 0xFFFF (note: not all are valid)
;WITH n(n) AS (SELECT a.i*256+b.i FROM @i a CROSS JOIN @i b),
	a(n,lo,hi,uni) AS 
	(SELECT n, SUBSTRING('0123456789ABCDEF',n%16+1,1) lo,
	CONVERT(CHAR(6),CAST(n/16*16 AS BINARY(2)),1) hi, NCHAR(n) uni
	FROM n)
SELECT hi hi_byte,[0],[1],[2],[3],[4],[5],[6],[7],[8],[9],[A],[B],[C],[D],[E],[F]
FROM (SELECT hi,lo,uni FROM a) y
PIVOT (MAX(uni) 
FOR lo IN ([0],[1],[2],[3],[4],[5],[6],[7],[8],[9],[A],[B],[C],[D],[E],[F])) z

-- more whitespace

;WITH uni(codepoint,Name,Script,Category,Remark) AS (
SELECT 0x0009,'','Common','Other, control','HT, Horizontal Tab' UNION ALL SELECT 
0x000A,'','Common','Other, control','LF, Line feed' UNION ALL SELECT 
--0x000B,'','Common','Other, control','VT, Vertical Tab' UNION ALL SELECT 
--0x000C,'','Common','Other, control','FF, Form feed' UNION ALL SELECT 
0x000D,'','Common','Other, control','CR, Carriage return' UNION ALL SELECT 
0x0020,'space','Common','Separator, space','' UNION ALL SELECT 
0x0085,'','Common','Other, control','NEL, Newline' UNION ALL SELECT 
0x00A0,'no-break space','Common','Separator, space','' UNION ALL SELECT 
0x1680,'ogham space mark', 'Ogham', 'Separator, space','' UNION ALL SELECT 
0x180E,'mongolian vowel separator','Mongolian', 'Separator, space','' UNION ALL SELECT 
0x2000,'en quad','Common','Separator, space','' UNION ALL SELECT 
0x2001,'em quad','Common','Separator, space','' UNION ALL SELECT 
0x2002,'en space','Common','Separator, space','' UNION ALL SELECT 
0x2003,'em space','Common','Separator, space','' UNION ALL SELECT 
0x2004,'three-per-em space','Common','Separator, space','' UNION ALL SELECT 
0x2005,'four-per-em space','Common','Separator, space','' UNION ALL SELECT 
0x2006,'six-per-em space','Common','Separator, space','' UNION ALL SELECT 
0x2007,'figure space','Common','Separator, space','' UNION ALL SELECT 
0x2008,'punctuation space','Common','Separator, space','' UNION ALL SELECT 
0x2009,'thin space','Common','Separator, space','' UNION ALL SELECT 
0x200A,'hair space','Common','Separator, space','' UNION ALL SELECT 
0x2028,'line separator','Common','Separator, line','' UNION ALL SELECT 
0x2029,'paragraph separator','Common','Separator, paragraph','' UNION ALL SELECT 
0x202F,'narrow no-break space','Common','Separator, space','' UNION ALL SELECT 
0x205F,'medium mathematical space','Common','Separator, space','' UNION ALL SELECT 
0x3000,'ideographic space','Common','Separator, space','')
SELECT *, NCHAR(codepoint) character FROM Uni;

-- more Unicode info

-- http://en.wikipedia.org/wiki/Unicode_Character_Properties#General_Category
-- http://en.wikipedia.org/wiki/Unicode_control_characters





-- And even more Unicode...another definition for SQL Bits!

DECLARE @oohbaby TABLE(i INT NOT NULL UNIQUE,
uni_char AS NCHAR(i),
hex AS CAST(i AS BINARY(2)))
INSERT @oohbaby VALUES(664),(1022),(1023),(1120),(1150),(8857),(11609),(42420),(42427)

-- change results font to larger size, some only work in grid font
SELECT * FROM @oohbaby

SELECT NCHAR(1022) + NCHAR(1023) AS Page3Girl
SELECT NCHAR(1120) 
SELECT NCHAR(42427)
